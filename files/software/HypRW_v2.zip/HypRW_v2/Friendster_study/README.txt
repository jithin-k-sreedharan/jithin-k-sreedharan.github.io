Data:
"friendster_community1_trimmed.edgelist" is a largest connected component extracted from one subgraph of Friendster. 
Data is collected from https://snap.stanford.edu/

The file "HypRW_friendster.py" plots the approximate posterior distribution and the empirical distribution

The Python script requires various modules like NetworkX, Scipy and NumPy.



